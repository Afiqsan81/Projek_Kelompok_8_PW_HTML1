// Smooth scroll for menu links
document.querySelectorAll('nav .menu a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();

        const targetId = this.getAttribute('href').substring(1);
        document.getElementById(targetId).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Function for "Pesan Sekarang!" buttons
function orderNow() {
    alert("Pemesanan Belum Bisa Diakses. Login Member Sekarang!");
}
