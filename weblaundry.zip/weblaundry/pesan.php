<?php
include 'db_connection.php';

$alertMessage = '';
$redirectToCopyloundry = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];
    $jenis_layanan = $_POST['jenis_layanan'];
    $tanggal_pesan = $_POST['tanggal_pesan'];
    
    // Query untuk memasukkan data ke database
    $sql = "INSERT INTO pemesanan (nama, alamat, no_telepon, jenis_layanan, tanggal_pesan) VALUES ('$nama', '$alamat', '$no_telepon', '$jenis_layanan', '$tanggal_pesan')";
    
    if ($conn->query($sql) === TRUE) {
        $alertMessage = "Pemesanan berhasil!";
        $redirectToCopyloundry = true;
    } else {
        $alertMessage = "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!-- pesan.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesan Sekarang - Laundry Baju dan Sepatu</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .wrapper {
            width: 100%;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"],
        input[type="date"],
        select {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            width: 100%;
        }

        input[type="submit"] {
            padding: 10px 15px;
            background: #28a745;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background: #218838;
        }

        .error {
            color: red;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Form Pemesanan</h2>
        <form id="orderForm" action="pesan.php" method="post">
            <div class="error" id="error"></div>
            <label for="nama">Nama:</label>
            <input type="text" id="nama" name="nama" required>
            
            <label for="alamat">Alamat:</label>
            <input type="text" id="alamat" name="alamat" required>
            
            <label for="no_telepon">No Telepon:</label>
            <input type="text" id="no_telepon" name="no_telepon" required>
            
            <label for="jenis_layanan">Jenis Layanan:</label>
            <select id="jenis_layanan" name="jenis_layanan" required>
                <option value="cuci_setrika">Cuci dan Setrika</option>
                <option value="cuci_kering">Cuci Kering</option>
                <option value="setrika">Setrika</option>
                <option value="cuci_sepatu">Cuci Sepatu</option>
            </select>
            
            <label for="tanggal_pesan">Tanggal Pesan:</label>
            <input type="date" id="tanggal_pesan" name="tanggal_pesan" required>
            
            <input type="submit" name="submit" value="Pesan Sekarang">
        </form>
    </div>

    <script>
        document.getElementById('orderForm').addEventListener('submit', function(event) {
            const nama = document.getElementById('nama').value;
            const alamat = document.getElementById('alamat').value;
            const noTelepon = document.getElementById('no_telepon').value;
            const jenisLayanan = document.getElementById('jenis_layanan').value;
            const tanggalPesan = document.getElementById('tanggal_pesan').value;
            const errorElement = document.getElementById('error');

            let messages = [];

            if (!nama.trim()) {
                messages.push('Nama harus diisi.');
            }

            if (!alamat.trim()) {
                messages.push('Alamat harus diisi.');
            }

            if (!noTelepon.trim()) {
                messages.push('No Telepon harus diisi.');
            }

            if (!jenisLayanan) {
                messages.push('Jenis Layanan harus dipilih.');
            }

            if (!tanggalPesan) {
                messages.push('Tanggal Pesan harus dipilih.');
            }

            if (messages.length > 0) {
                event.preventDefault();
                errorElement.innerText = messages.join(', ');
            }
        });

        <?php if (!empty($alertMessage)): ?>
            alert("<?php echo $alertMessage; ?>");
            <?php if ($redirectToCopyloundry): ?>
                window.location.href = 'copyloundry.html';
            <?php endif; ?>
        <?php endif; ?>
    </script>
</body>
</html>
