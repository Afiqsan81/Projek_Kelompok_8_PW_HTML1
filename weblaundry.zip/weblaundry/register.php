<?php
// Start the session
session_start();

// Include database connection file
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get data from form
    $username = $_POST['username'];
    $password = $_POST['password'];
    $nama = $_POST['nama']; // Adding 'nama' field
    $alamat = $_POST['alamat']; // Adding 'alamat' field

    // Check if username already exists
    $check_query = "SELECT * FROM akun WHERE username = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("s", $username);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        echo "<script>alert('Username already exists. Please choose a different username.');</script>";
    } else {
        // Insert new user into database
        $insert_query = "INSERT INTO akun (username, password, nama, alamat) VALUES (?, ?, ?, ?)";
        $insert_stmt = $conn->prepare($insert_query);
        $insert_stmt->bind_param("ssss", $username, $password, $nama, $alamat);
        
        if ($insert_stmt->execute()) {
            // Registration successful, set session and redirect to login page
            $_SESSION['username'] = $username;
            echo "<script>alert('Registrasi Berhasil'); window.location='login.php';</script>";
            exit();
        } else {
            echo "<script>alert('Registration Gagal');</script>";
        }
    }

    $check_stmt->close();
    $insert_stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f8f5;
            font-family: Arial, sans-serif;
        }
        .register-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }
        .register-container h2 {
            text-align: center;
            color: #119527;
            margin-bottom: 20px;
        }
        .register-container label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .register-container input[type="text"], 
        .register-container input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .register-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #119527;
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .register-container input[type="submit"]:hover {
            background-color: #0e7a41;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Register</h2>
        <form action="register.php" method="post">
            <label for="nama">Nama:</label>
            <input type="text" id="nama" name="nama" required>
            <label for="alamat">Alamat:</label>
            <input type="text" id="alamat" name="alamat" required>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <input type="submit" value="Register">
        </form>
    </div>
</body>
</html>
